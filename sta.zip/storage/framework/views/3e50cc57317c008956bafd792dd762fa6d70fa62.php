
 
<?php $__env->startSection('content'); ?>
<div class="row">
    
    <?php if($usertype != 'staff'): ?>
        <div class="col-sm-6" style="margin-bottom: 10px;">
            <div class="card pendingCard">
                <?php if($usertype == 'supervisor'): ?>
                <h3 style="background-color: rgba(255, 0, 0, 0.5); margin: 0; padding: 10px; color: white; text-align: center;">Pending for Authorization</h3>
                <?php else: ?>
                <h3 style="background-color: rgba(255, 0, 0, 0.5); margin: 0; padding: 10px; color: white; text-align: center;">Pending for Confirmation</h3>
                <?php endif; ?>
                <div style="overflow-x: hidden; height: 270px;">
                    <?php if(!$transactions): ?>
                        <div style="padding: 1px 10px;" class="card-body">
                            <h4 style="text-align: center;">No pending records.</h4>
                        </div>
                    <?php else: ?>
                    <hr style="margin: 0;">
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($trans->id): ?>
                                <?php if($trans->isOpened): ?>
                                <a class="pendingTransA" href="<?php echo e(route('transactions.edit',$trans->id)); ?>">
                                    <div style="padding: 1px 10px; box-shadow: inset 5px 0 0 0 rgb(172, 112, 0);" class="card-body">
                                        <span style="height: 100%; width:10px; background-color: limegreen;"></span>
                                        <h4 class="card-title"><i class="far fa-envelope-open"></i> Transaction No: <?php echo e($trans->transNo); ?></h4>
                                        <h5 class="card-text">Status: <?php echo e($trans->status); ?></h5>
                                        <h5 class="card-text">Transfer Date: <?php echo e($trans->transferDate); ?></h5>
                                    </div>
                                </a>
                                <?php else: ?>
                                <a class="pendingTransA" href="<?php echo e(route('transactions.edit',$trans->id)); ?>">
                                    <div style="padding: 1px 10px; box-shadow: inset 5px 0 0 0 rgb(158, 0, 0);" class="card-body">
                                        <span style="height: 100%; width:10px; background-color: limegreen;"></span>
                                        <h4 class="card-title"><b><i class="fa fa-envelope" aria-hidden="true"></i> Transaction No: <?php echo e($trans->transNo); ?></b></h4>
                                        <h5 class="card-text"><b>Status: <?php echo e($trans->status); ?></b></h5>
                                        <h5 class="card-text"><b>Transfer Date: <?php echo e($trans->transferDate); ?></b></h5>
                                    </div>
                                </a>
                                <?php endif; ?>
                                <hr style="margin: 0;">
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-sm-6" style="margin-bottom: 10px;">
            <div class="card upcomingCard">
                <?php if($usertype == 'supervisor'): ?>
                    <h3 style="background-color:  rgba(0, 158, 71, 0.5); margin: 0; padding: 10px; color: white; text-align: center;">Authorized</h3>
                    <div style="overflow-x: hidden; height: 270px;">
                        <?php if(!$transactionsCP): ?>
                            <div style="padding: 1px 10px;" class="card-body">
                                <h4 style="text-align: center;">No Authorized records.</h4>
                            </div>
                        <?php else: ?>
                        <hr style="margin: 0;">
                            <?php $__currentLoopData = $transactionsCP; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="confirmedTrans" href="<?php echo e(route('transactions.show',$trans->id)); ?>">
                                    <div style="padding: 1px 10px;" class="card-body">
                                        <span style="height: 100%; width:10px; background-color: limegreen;"></span>
                                        <h4 class="card-title">Transaction No: <?php echo e($trans->transNo); ?></h4>
                                        <h5 class="card-text">Status: <?php echo e($trans->status); ?></h5>
                                        <h5 class="card-text">Transfer Date: <?php echo e($trans->transferDate); ?></h5>
                                    </div>
                                </a>
                                <hr style="margin: 0;">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                <?php elseif($usertype == 'manager'): ?>
                    <h3 style="background-color:  rgba(0, 158, 71, 0.5); margin: 0; padding: 10px; color: white; text-align: center;">Confirmed and Processed</h3>
                    <div style="overflow-x: hidden; height: 270px;">
                        <?php if(!$transactionsCP): ?>
                            <div style="padding: 1px 10px;" class="card-body">
                                <h4 style="text-align: center;">No Confirmed and Processed records.</h4>
                            </div>
                        <?php else: ?>
                        <hr style="margin: 0;">
                            <?php $__currentLoopData = $transactionsCP; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="confirmedTrans" href="<?php echo e(route('transactions.show',$trans->id)); ?>">
                                    <div style="padding: 1px 10px;" class="card-body">
                                        <span style="height: 100%; width:10px; background-color: limegreen;"></span>
                                        <h4 class="card-title">Transaction No: <?php echo e($trans->transNo); ?></h4>
                                        <h5 class="card-text">Status: <?php echo e($trans->status); ?></h5>
                                        <h5 class="card-text">Transfer Date: <?php echo e($trans->transferDate); ?></h5>
                                    </div>
                                </a>
                                <hr style="margin: 0;">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <hr>
    <?php endif; ?>
    <div class="col-sm-12">
        <div class="col-sm-9">
            <h3>Upcoming:</h3>
        </div>
        <div class="col-sm-3">
            <?php if($usertype == 'staff'): ?>
            <a style="display: block;" class="btn btn-success" href="<?php echo e(route('transactions.create')); ?>">New Transaction</a>
            <?php endif; ?>
        </div>
        <div class="col-sm-12" style="overflow-y: hidden; height: 100%; margin: 10px 0;">
            <table style="border-collapse: collapse; width: 100%;" id="transactionTable" class="table table-bordered table-striped">
                <thead>
                    <tr style="">
                        <th style="position: sticky; top: 0; background-color: white;">Trans. No</th>
                        <th style="position: sticky; top: 0; background-color: white;">Emp. Code</th>
                        <th style="position: sticky; top: 0; background-color: white;">Transfer Date</th>
                        <th style="position: sticky; top: 0; background-color: white;">Warehouse From</th>
                        <th style="position: sticky; top: 0; background-color: white;">Warehouse To</th>
                        <th style="position: sticky; top: 0; background-color: white;">Reference</th>
                        <th style="position: sticky; top: 0; background-color: white;">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $transactionsToday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a class="confirmedTrans" href="<?php echo e(route('transactions.show',$trans->id)); ?>"><b><?php echo e($trans->transNo); ?></b></a></td>
                        <td><?php echo e($trans->employeeCode); ?></td>
                        <td><?php echo e($trans->transferDate); ?></td>
                        <td><?php echo e($trans->warehouseFrom); ?></td>
                        <td><?php echo e($trans->warehouseTo); ?></td>
                        <td><?php echo e($trans->reference); ?></td>
                        <td><?php echo e($trans->status); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
  $('#transactionTable').DataTable();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\sta\resources\views/home/index.blade.php ENDPATH**/ ?>