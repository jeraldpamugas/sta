
 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h3 style="margin: 0;">Transactions</h3>
            </div>
            <div class="pull-right">
                <?php if($usertype == 'staff'): ?>
                <a class="btn btn-success" href="<?php echo e(route('transactions.create')); ?>"> Add New Transactions</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <hr>
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <div style="overflow-y: hidden;">
        <table id="transactionTable" class="table table-striped">
            <tr>
                <th>     </th>
                <th>Trans. No</th>
                <th>Emp. Code</th>
                <th>TransferDate</th>
                <th>WarehouseFrom</th>
                <th>WarehouseTo</th>
                <th>Reference</th>
                <th>Status</th>
                <th>AuthorizeBy</th>
                <th>AuthorizeDate</th>
                <th>ConfirmedBy</th>
                <th>ConfirmedDate</th>
                <th>ProcessBy</th>
                <th>ProcessedDate</th>
                <th>SysCreated</th>
                <th>SysCreator</th>
                <th>SysModified</th>
                <th>SysModifier</th>
            </tr>
            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <?php if($usertype != 'staff'): ?>
                    <?php if($trans->status == 'P'): ?>
                        <td title="Processed!" style="text-align: center"><i style="color: rgb(3, 128, 3);" class="fas fa-check"></i></td>
                    <?php elseif($trans->status == 'C'): ?>
                        <td title="Confirmed!" style="text-align: center"><a href="<?php echo e(route('transactions.edit',$trans->id)); ?>"><i style="color: lime;" class="fas fa-check"></i></a></td>
                    <?php elseif($trans->status == 'A'): ?>
                        <td title="Authorized!" style="text-align: center"><a href="<?php echo e(route('transactions.edit',$trans->id)); ?>"><i style="color: lime;" class="fas fa-check"></i></a></td>
                    <?php elseif($trans->transferDate < date('Y-m-d H:i:s')): ?>
                        <td title="Transaction Expired!" style="text-align: center"><i style="font-size:14px;color: red;" class="fas fa-times"><i class="fa fa-exclamation-triangle" style="font-size:10px;color:red"></i></i></td>
                    <?php else: ?>
                        <td title="Not yet Authorized!" style="text-align: center"><a href="<?php echo e(route('transactions.edit',$trans->id)); ?>"><i style="color: rgb(179, 0, 0);" class="fas fa-times"></i></a></td>
                    <?php endif; ?>
                <?php else: ?>
                    <?php if($trans->status == 'P'): ?>
                        <td title="Processed!" style="text-align: center"><i style="color: rgb(3, 128, 3);" class="fas fa-check 2x"></i></td>
                    <?php elseif($trans->status == 'C'): ?>
                        <td title="Confirmed!" style="text-align: center"><i style="color: lime;" class="fas fa-check"></i></td>
                    <?php elseif($trans->status == 'A'): ?>
                        <td title="Authorized!" style="text-align: center"><i style="color: lime;" class="fas fa-check"></i></td>
                    <?php elseif($trans->transferDate < date('Y-m-d H:i:s')): ?>
                        <td title="Transaction Expired!" style="text-align: center"><i style="font-size:14px;color: red;" class="fas fa-times"><i class="fa fa-exclamation-triangle" style="font-size:10px;color:red"></i></i></td>
                    <?php else: ?>
                        <td title="Not yet Authorized!" style="text-align: center"><i style="color: rgb(179, 0, 0);" class="fas fa-times"></i></td>
                    <?php endif; ?>
                <?php endif; ?>
                <td><a href="<?php echo e(route('transactions.show',$trans->id)); ?>"><b><?php echo e($trans->transNo); ?></b></a></td>
                <td><?php echo e($trans->employeeCode); ?></td>
                <td><?php echo e($trans->transferDate); ?></td>
                <td><?php echo e($trans->warehouseFrom); ?></td>
                <td><?php echo e($trans->warehouseTo); ?></td>
                <td><?php echo e($trans->reference); ?></td>
                <td style="text-align: center"><?php echo e($trans->status); ?></td>
                <td><?php echo e($trans->authorizedBy); ?></td>
                <td><?php echo e($trans->authorizedDate); ?></td>
                <td><?php echo e($trans->confirmedBy); ?></td>
                <td><?php echo e($trans->confirmedDate); ?></td>
                <td><?php echo e($trans->processedBy); ?></td>
                <td><?php echo e($trans->processedDate); ?></td>
                <td><?php echo e($trans->created_at); ?></td>
                <td><?php echo e($trans->syscreator); ?></td>
                <td><?php echo e($trans->updated_at); ?></td>
                <td><?php echo e($trans->sysmodifier); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
   </div>
  <script>
    $('#transactionTable').DataTable();
  </script>
   
   
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\sta\resources\views/transactions/index.blade.php ENDPATH**/ ?>