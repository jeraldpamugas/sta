
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h4 style="margin: 0px;">Transaction No: <b><?php echo e($transaction[0]['transNo']); ?></b></h4>
            </div>
            <div class="pull-right">
                <a id="btnBackFromEditTrans" class="btn" href="#"> Back</a>
            </div>
        </div>
        <div id="report" class="col-sm-12" style='margin: auto;'>
           <hr>
            <div class="row">
                <div class="col-sm-12">
                    <div class="col-sm-12">
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Id:</strong>
                                <?php echo e($transaction[0]['id']); ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Employee Code:</strong>
                                <?php echo e($transaction[0]['employeeCode']); ?>

                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Transfer Date:</strong>
                                <?php echo e($transaction[0]['transferDate']); ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>WarehouseFrom:</strong>
                                <?php echo e($transaction[0]['warehouseFrom']); ?>

                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>WarehouseTo:</strong>
                                <?php echo e($transaction[0]['warehouseTo']); ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Reference:</strong>
                                <?php echo e($transaction[0]['reference']); ?>

                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong>Status:</strong>
                                <?php echo e($statusVal); ?>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="col-sm-12">
                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <h4>Items:</h4>
                            <div style="overflow-x: hidden;">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Item Code</th>
                                            <th>Description</th>
                                            <th>Unit</th>
                                            <th>Quantity</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $translinesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item['itemCode']); ?></td>
                                                <td><?php echo e($item['Description']); ?></td>
                                                <td><?php echo e($item['unit']); ?></td>
                                                <td><?php echo e($item['quantity']); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-12">
            <div class="col-sm-3">
                <button id="btnReport" type="button" class="btn btn-primary" style="display: block; width: 100%;" onclick="showReport()">Generate</button>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        function showReport(){

            $("#btnReport").hide();
            $("#btnBackFromEditTrans").hide();
            window.print();
            $("#btnReport").show();
            $("#btnBackFromEditTrans").show();
            
        }

        $('#btnBackFromEditTrans').click( function(e) {
            e.preventDefault(); 
            window.history.back(); return false; 
        });
    
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\sta\resources\views/transactions/show.blade.php ENDPATH**/ ?>