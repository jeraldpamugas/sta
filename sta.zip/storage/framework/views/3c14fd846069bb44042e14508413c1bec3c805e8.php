
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h4>Transaction No: <b><?php echo e($transaction->transNo); ?></b></h4>
            </div>
            <div class="pull-right">
                <a id="btnBackFromEditTrans" class="btn" href="#">Back</a>
            </div>
        </div>
    </div>
    <hr>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form id="transForm">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="row">
            <input type="hidden" name="wrId" id="wrId" value="<?php echo e($transaction->id); ?>">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="col-sm-4 form-group">
                    <strong>Employee Code:</strong>
                    <input type="text" class="form-control" value="<?php echo e($transaction->employeeCode); ?>" disabled>
                </div>
                <div class="col-sm-4 form-group">
                    <strong>Reference:</strong>
                    <input type="text" class="form-control" value="<?php echo e($transaction->reference); ?>" disabled>
                </div>
                <div class="col-sm-4 form-group">
                    <strong>Status:</strong>
                    <input type="text" class="form-control" value="<?php echo e($transaction->status); ?>" disabled>
                </div>
                <div class="col-sm-4 form-group">
                    <strong>warehouseFrom:</strong>
                    <input type="text" class="form-control" value="<?php echo e($transaction->warehouseFrom); ?>" disabled>
                </div>
                <div class="col-sm-4 form-group">
                    <strong>warehouseTo:</strong>
                    <input type="text" class="form-control" value="<?php echo e($transaction->warehouseTo); ?>" disabled>
                </div>
                <div class="col-sm-4 form-group">
                    <strong>TransferDate:</strong>
                    <input type="text" class="form-control" value="<?php echo e($transaction->transferDate); ?>" disabled>
                </div>
                <div class="col-sm-14">
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <h4>Items:</h4>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Item Code</th>
                                    <th>Unit</th>
                                    <th>Quantity</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $translinesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->itemCode); ?></td>
                                        <td><?php echo e($item->unit); ?></td>
                                        <td><?php echo e($item->quantity); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <?php if($usertype == 'supervisor' && $transaction->status == 'O'): ?>
                        <input id="status" name="status" type="hidden" value="A">
                        <div class="col-sm-12">
                            <button type="submit" class="btn btn-primary" style="display: block; width: 100%; margin-top: 18px;">Authorize</button>
                        </div>
                    <?php elseif($usertype == 'manager' && $transaction->status == 'A' || $usertype == 'manager' && $transaction->status == 'C'): ?>
                        <?php if($transaction->status == 'A'): ?>
                        <input id="status" name="status" type="hidden" value="C">
                        <?php elseif($transaction->status == 'C'): ?>
                        <input id="status" name="status" type="hidden" value="P">
                        <?php endif; ?>
                        <div class="col-sm-12">
                            <?php if($transaction->status == 'A'): ?>
                                <button type="submit" class="btn btn-primary" style="display: block; width: 100%; margin-top: 18px;">Confirm</button>
                            <?php elseif($transaction->status == 'C'): ?>
                                <button type="submit" class="btn btn-primary" style="display: block; width: 100%; margin-top: 18px;">Process</button>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </form>
    <script>

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $('#transForm').on('submit', function(event) {

        event.preventDefault();

        var status = $('#status').val();
        var id = $("#wrId").val();
        let _url     = '/updatetrans';
        let _token   = $('meta[name="csrf-token"]').attr('content');

        $.ajax({
            url: _url,
            type: "POST",
            data: {
                id: id,
                status: status,
                _token: _token,
            },
            success: function(response) {
                if(response == 'Invalid Status'){
                    alert("Please enter a valid status!");
                }
                else{
                // window.history.back();
                // location.reload();
                window.location = document.referrer;
                }
            },
            error: function(response) {
                alert('Press ok to refresh the page!');
                location.reload();
            }
        });
    });

    $('#btnBackFromEditTrans').click( function(e) {
        e.preventDefault();
        window.location = document.referrer;
        // window.history.back(); return false;
    });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\sta\resources\views/transactions/edit.blade.php ENDPATH**/ ?>