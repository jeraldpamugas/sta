
 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Items</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('items.create')); ?>"> Add New Items</a>
            </div>
        </div>
    </div>
    <hr>
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
   
    <div style="overflow-y: hidden;">
        <table class="table table-striped">
            <tr>
                <th>Id</th>
                <th>Item Code</th>
                <th>Description</th>
                <th>Unit</th>
                <th>Action</th>
            </tr>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->itemCode); ?></td>
                <td><?php echo e($item->Description); ?></td>
                <td><?php echo e($item->unit); ?></td>
                <td>
                    <form action="<?php echo e(route('items.destroy', $item->id)); ?>" method="POST">
    
                        <a class="btn btn-info" href="<?php echo e(route('items.show',$item->id)); ?>">Show</a>
        
                        <a class="btn btn-primary" href="<?php echo e(route('items.edit',$item->id)); ?>">Edit</a>
    
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
        
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\sta\resources\views/items/index.blade.php ENDPATH**/ ?>