
 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h3 style="margin: 0;">Warehouse</h3>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('warehouses.create')); ?>"> Add New Warehouse</a>
            </div>
        </div>
    </div>
    <hr>
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
   
    <div style="overflow-y: hidden;">
        <table class="table table-striped">
            <tr>
                <th>Id</th>
                <th>Warehouse Code</th>
                <th>Description</th>
                <th>Action</th>
            </tr>
            <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($warehouse->id); ?></td>
                <td><?php echo e($warehouse->warehouseCode); ?></td>
                <td><?php echo e($warehouse->description); ?></td>
                <td>
                    <div>
                        <div class="col-sm-4">
                            <a style="display: block; margin: 2px;" class="btn btn-info" href="<?php echo e(route('warehouses.show',$warehouse->id)); ?>"><i class="fa fa-eye" aria-hidden="true"></i></a>
                        </div>
                        <div class="col-sm-4">
                            <a style="display: block; margin: 2px;" class="btn btn-primary" href="<?php echo e(route('warehouses.edit',$warehouse->id)); ?>"><i class="fa fa-edit" ></i></a>
                        </div>
                        <div class="col-sm-4">
                            <a style="display: block; margin: 2px;" class="btn btn-danger" href="<?php echo e(route('warehouses.destroy', $warehouse->id)); ?>"><i class="fa fa-trash" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\sta\resources\views/warehouses/index.blade.php ENDPATH**/ ?>